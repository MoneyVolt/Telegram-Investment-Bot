export const PATH_SERVER = "/server"
