// Button click events
export const MAIN_BUTTON_CLICK_EVENT = 'mainButtonClicked'
export const BACK_BUTTON_CLICK_EVENT = 'backButtonClicked'
export const SETTINGS_BUTTON_CLICK_EVENT = 'settingsButtonClicked'

