import {launchApp} from "./app/Application.js";

// Launch our application
launchApp()
